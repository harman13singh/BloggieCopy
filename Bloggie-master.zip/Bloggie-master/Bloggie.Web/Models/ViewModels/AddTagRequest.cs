﻿namespace Bloggie.Web.Models.NewFolder2
{
    public class AddTagRequest
    {
    }
}
